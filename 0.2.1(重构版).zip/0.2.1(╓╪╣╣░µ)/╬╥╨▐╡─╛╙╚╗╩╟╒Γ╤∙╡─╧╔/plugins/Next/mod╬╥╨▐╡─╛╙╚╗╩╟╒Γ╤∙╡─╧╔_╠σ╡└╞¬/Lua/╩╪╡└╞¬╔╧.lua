local 守道篇上 = {}

function 守道篇上.守道之约1(runner, env)
	runner.SetChar("唐守道", 7703)
	runner.PSay("眼前居然有一个熟人,这好像是前段时间体道大会里，表现非常出色的那个修士。")
	runner.Say("主角","幸会幸会。")
	runner.Say("唐守道","道友客气，找我有什么事吗？")
	runner.ShowOption("1:我想交流一些体道的心得。")
	runner.Say("唐守道","上了筑基以后，对体道又有了不一样的感悟。")
	runner.Say("唐守道","此前觉得，体道的核心是淬体。通过身体的强度战斗与突破。")
	runner.Say("唐守道","现在看来，身体的强度在每个阶段都是有上限的。")
	runner.Say("唐守道","很多时候应该假借于物，利用天时，地利，周围的环境。")
	runner.Say("唐守道","达到四两拨千斤的效果，而不是一味只提高身体强度。")
	runner.Say("主角","兄弟所言极是，我受益匪浅啊。")
	runner.Say("唐守道","此外，修仙途中一定要保证道心坚定。")
	runner.Say("唐守道","许多时候，只有超然物外的心境，才能做成一些事情。")
	runner.Say("主角","确为如此。")
	runner.Say("唐守道","道友还有何事吗？")
	runner.ShowOption("1:打听一下最近的情况。","2:没有了。")
	if env.optionID == 1 then
		runner.Say("唐守道","最近宁州倒是暗流涌动，我隐隐感觉有事情要发生。")
		runner.Say("唐守道","不过或许是我的错觉，道友不必在意哈！")
	elseif env.optionID == 2 then
        runner.Say("唐守道","好的，那有缘再会。")
    end
end

function 守道篇上.奇灵生魔1(runner, env)
	runner.SetChar("唐守道", 7703)
	runner.PSay("来到奇灵山时，唐守道已经等候多时。")
	runner.Say("主角","来得挺早啊。")
	runner.Say("唐守道","哈哈，宝贝，那自然是先到先得嘛。")
	runner.Say("主角","那守道兄对这奇宝有什么头绪嘛？")
	runner.Say("唐守道","那自然已经是准备充分了。")
end

return 守道篇上