local 入魔篇下 = {}

function 入魔篇下.偷听对话1(runner, env)
	runner.SetChar("祁无悔", 7803)
	runner.SetChar("邢何度", 7804)
	runner.PSay("你路过议事厅，却听到里面传来激烈的争论声。")
	runner.Say("邢何度","无悔！你究竟想做什么，就算是在济州，如此大规模的屠杀，都是难以接受的行为。")
	runner.Say("邢何度","我们虽然是魔教，但是也不能如此没有底线吧。")
	runner.Say("邢何度","无悔！你究竟想做什么，就算是在济州，如此大规模的屠杀，都是难以接受的行为。")
end

return 入魔篇下