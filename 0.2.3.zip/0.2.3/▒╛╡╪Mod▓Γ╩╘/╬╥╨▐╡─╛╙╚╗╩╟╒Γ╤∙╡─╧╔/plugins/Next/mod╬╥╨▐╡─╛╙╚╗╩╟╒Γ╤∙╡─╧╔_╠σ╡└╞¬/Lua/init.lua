local init_skill = {}

function init_skill.skillpart1(runner, env)
	-- 宁州体修数据
	runner.NpcChangeSkill(7701, "change",701, 77001)
	runner.NpcChangeSkill(7701, "change",501, 77006)
	runner.NpcChangeSkill(7701, "change",504, 77011)
	runner.NpcChangeSkill(7701, "add", 77016)

    runner.NpcChangeAutoStaticSkill(7701, "change", 522,37001)
    runner.NpcChangeAutoStaticSkill(7701, "change", 523,37006)
    runner.NpcChangeAutoAskStaticSkill(7701, "change", 522,37001)
    runner.NpcChangeAutoAskStaticSkill(7701, "change", 523,37006)

    runner.NpcChangeAskSkill(7701, "change",701, 77001)
	runner.NpcChangeAskSkill(7701, "change",501, 77006)
	runner.NpcChangeAskSkill(7701, "change",504, 77011)
	runner.NpcChangeAskSkill(7701, "add", 77016)
--
    runner.NpcChangeSkill(7704, "change",701, 77001)
	runner.NpcChangeSkill(7704, "change",501, 77006)
	runner.NpcChangeSkill(7704, "change",504, 77011)
	runner.NpcChangeSkill(7704, "add", 77016)

    runner.NpcChangeAutoStaticSkill(7704, "change", 522,37001)
    runner.NpcChangeAutoStaticSkill(7704, "change", 523,37006)
    runner.NpcChangeAutoAskStaticSkill(7704, "change", 522,37001)
    runner.NpcChangeAutoAskStaticSkill(7704, "change", 523,37006)

    runner.NpcChangeAskSkill(7704, "change",701, 77001)
	runner.NpcChangeAskSkill(7704, "change",501, 77006)
	runner.NpcChangeAskSkill(7704, "change",504, 77011)
	runner.NpcChangeAskSkill(7704, "add", 77016)
--
	runner.NpcChangeSkill(7705, "change",701, 77001)
	runner.NpcChangeSkill(7705, "change",501, 77006)
	runner.NpcChangeSkill(7705, "change",504, 77011)
	runner.NpcChangeSkill(7705, "add", 77016)

    runner.NpcChangeAutoStaticSkill(7705, "change", 522,37001)
    runner.NpcChangeAutoStaticSkill(7705, "change", 523,37006)
    runner.NpcChangeAutoAskStaticSkill(7705, "change", 522,37001)
    runner.NpcChangeAutoAskStaticSkill(7705, "change", 523,37006)

    runner.NpcChangeAskSkill(7705, "change",701, 77001)
	runner.NpcChangeAskSkill(7705, "change",501, 77006)
	runner.NpcChangeAskSkill(7705, "change",504, 77011)
	runner.NpcChangeAskSkill(7705, "add", 77016)
--
	runner.NpcChangeSkill(7706, "change",701, 77001)
	runner.NpcChangeSkill(7706, "change",501, 77006)
	runner.NpcChangeSkill(7706, "change",504, 77011)
	runner.NpcChangeSkill(7706, "add", 77016)

    runner.NpcChangeAutoStaticSkill(7706, "change", 522,37001)
    runner.NpcChangeAutoStaticSkill(7706, "change", 523,37006)
    runner.NpcChangeAutoAskStaticSkill(7706, "change", 522,37001)
    runner.NpcChangeAutoAskStaticSkill(7706, "change", 523,37006)

    runner.NpcChangeAskSkill(7706, "change",701, 77001)
	runner.NpcChangeAskSkill(7706, "change",501, 77006)
	runner.NpcChangeAskSkill(7706, "change",504, 77011)
	runner.NpcChangeAskSkill(7706, "add", 77016)

	--runner.PSay("成功执行初始化1")
end

function init_skill.skillpart2(runner, env)
	-- 唐守道数据
	runner.NpcChangeAutoStaticSkill(7703, "change", 522, 37021)
	runner.NpcChangeAutoStaticSkill(7703, "change", 523, 37026)
	runner.NpcChangeAutoStaticSkill(7703, "change", 509, 37031)
	runner.NpcChangeAutoAskStaticSkill(7703, "change", 522, 37021)
    runner.NpcChangeAutoAskStaticSkill(7703, "change", 523, 37026)
    runner.NpcChangeAutoAskStaticSkill(7703, "change", 509, 37031)

	runner.NpcChangeSkill(7703, "change",501, 77076)
	runner.NpcChangeSkill(7703, "change",504, 77081)
	runner.NpcChangeSkill(7703, "add", 77086)
	runner.NpcChangeSkill(7703, "add", 77091)
	runner.NpcChangeSkill(7703, "add", 77096)

	runner.NpcChangeAskSkill(7703, "change",501, 77076)
	runner.NpcChangeAskSkill(7703, "change",504, 77081)
	runner.NpcChangeAskSkill(7703, "add", 77086)
	runner.NpcChangeAskSkill(7703, "add", 77091)
	runner.NpcChangeAskSkill(7703, "add", 77096)

	--runner.PSay("成功执行初始化2")
end

function init_skill.skillpart3(runner, env)
	-- 小柒数据
	runner.NpcChangeAutoStaticSkill(7702, "change", 522, 37011)
	runner.NpcChangeAutoStaticSkill(7702, "change", 523, 504)
	runner.NpcChangeAutoStaticSkill(7702, "change", 509, 208)
	runner.NpcChangeAutoAskStaticSkill(7702, "change", 522, 37011)
    runner.NpcChangeAutoAskStaticSkill(7702, "change", 523, 504)
    runner.NpcChangeAutoAskStaticSkill(7702, "change", 509, 208)

	runner.NpcChangeSkill(7702, "change",501, 77071)
	runner.NpcChangeSkill(7702, "change",504, 77031)
	runner.NpcChangeSkill(7702, "add", 77026)
	runner.NpcChangeSkill(7702, "add", 77021)
	runner.NpcChangeSkill(7702, "add", 557)

	runner.NpcChangeAskSkill(7702, "change",501, 77071)
	runner.NpcChangeAskSkill(7702, "change",504, 77031)
	runner.NpcChangeAskSkill(7702, "add", 77026)
	runner.NpcChangeAskSkill(7702, "add", 77021)
	runner.NpcChangeAskSkill(7702, "add", 557)

	--runner.PSay("成功执行初始化3")
end

return init_skill
