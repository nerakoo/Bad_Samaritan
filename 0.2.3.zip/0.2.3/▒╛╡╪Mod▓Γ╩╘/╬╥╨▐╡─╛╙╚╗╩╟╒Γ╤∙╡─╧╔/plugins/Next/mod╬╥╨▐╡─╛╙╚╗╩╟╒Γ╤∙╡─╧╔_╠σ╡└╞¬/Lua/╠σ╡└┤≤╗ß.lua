local 体道大会 = {}

function 体道大会.小节1(runner, env)
	runner.SetChar("李大锤", 7701)
	runner.PSay("来到奇灵山山脚，这里果然聚集了很多体修，非常热闹。你在人群中看到了一个熟悉的身影。")
	runner.Say("主角","是大锤道友吗？")
	runner.Say("李大锤","啊哈哈，幸会，幸会啊！")
	runner.PSay("李大锤看到你，也露出了笑容。")
	runner.Say("李大锤","这体道大会可是一个切磋交流的好机会，道友可以四处逛逛，看看能否有所收获。")
	runner.SetInt("体道大会开始", 10)
	runner.SetInt("体道大会切磋", 10)
	runner.SetInt("鹤羽扇", 1)
	runner.SetInt("蚕丝纱衣", 1)
	runner.SetInt("流心玉", 1)
end

function 体道大会.小节2(runner, env)
	runner.SetChar("王大壮", 7704)
	runner.PSay("你看到一个体格健壮的人蹲在会场中。")
	runner.Say("王大壮","优质的体修法宝，便宜卖了！")
	runner.Say("主角","道友，能给我介绍一下你这的货吗？")
	runner.Say("王大壮","当然，我这都是一等一的好货。")
	runner.Say("王大壮","这把鹤羽扇，是人阶上品的武器，使用后有利于在战斗中吸收木属性灵气。我便宜点，600灵石。")
	runner.Say("王大壮","这件蚕丝纱衣，是人阶上品的防具，使用后可以让你在战斗中动用神通威力更大。我也打个折，600灵石。")
	runner.Say("王大壮","这块流心玉，是地阶中品的宝贝，使用后可以增加你的灵气上限，是我压箱底的宝贝，2800灵石卖你不算亏吧。")
	runner.PSay("你思索了一下，想要：")
	runner.ShowOption("1:我想买鹤羽扇。","2:我想买蚕丝纱衣。","3:我想买流心玉。","4:我什么也不想买。")
	if env.optionID == 1 then
		runner.Say("王大壮","道友好魄力。")
		runner.AddItem(80063,1,1)
		runner.ChangeMoney(-600)
		runner.SetInt("鹤羽扇", 0)
	elseif env.optionID == 2 then
		runner.Say("王大壮","道友好眼光。")
		runner.AddItem(80064,1,1)
		runner.ChangeMoney(-600)
		runner.SetInt("蚕丝纱衣", 0)
	elseif env.optionID == 3 then
		runner.Say("王大壮","道友可真是慧眼识珠。")
		runner.AddItem(80065,1,1)
		runner.ChangeMoney(-2800)
		runner.SetInt("流心玉", 0)
	elseif env.optionID == 4 then
		runner.Say("王大壮","改主意了就再找我哦。")
	else
		runner.Say("王大壮","我可没货了。")
	end
end

function 体道大会.小节3(runner, env)
	runner.SetChar("苏大强", 7705)
	runner.Say("苏大强","道友，既然来了体道大会，何不切磋一番？")
	runner.Say("苏大强","我这有两本神通秘籍，就当切磋的彩头了，若是道友赢了，便双手奉上。")
	runner.Say("主角","这倒是个锻炼身手的好机会...")
	runner.ShowOption("1:那就切磋一番吧。","2:这次还是算了。")
	if env.optionID == 1 then
        runner.Say("苏大强","哈哈，那我可要全力以赴。")
        runner.StartFight(7705,1,8,1,"战斗1","","","nearko体道大会-切磋胜利","nearko体道大会-切磋失败","")
    elseif env.optionID == 2 then
        runner.Say("苏大强","那可真是遗憾。")
    end
end

function 体道大会.小节4(runner, env)
	runner.SetChar("牛大勇", 7706)
	runner.PSay("你看到一个人站在角落，若有所思。")
	runner.Say("主角","道友有何心事吗？")
	runner.Say("牛大勇","心事倒是没有，只是对体道和人生有了些困惑。")
	runner.Say("牛大勇","敢问道友可否为我答疑解惑？")
	runner.Say("主角","但说无妨。")
	runner.Say("牛大勇","道友认为，修仙追求的是什么？")
	runner.ShowOption("1:逍遥自在。","2:人生阅历。","3:长生。")
	runner.Say("牛大勇","道友认为，炼体的最大缺陷是什么？")
	runner.ShowOption("1:修为增长缓慢。","2:没有强大的神通护身。","3:缺乏高阶功法。")
	runner.Say("牛大勇","如若道友在追求长生的路中，身边重要的人身死道消，道友还会觉得长生意义重大吗？")
	runner.ShowOption("1:这反而更坚定了我修行的决心。","2:或许会有所惋惜吧。","3:我可能会怀疑自己。")
	runner.Say("牛大勇","如果有一种方法，能够让你修为暴涨，但是需要用他人的生命献祭，道友你会使用它吗？")
	runner.ShowOption("1:那必然是不会。","2:我也不知道...","3:其他人都是我成功路上的垫脚石罢了。")
	runner.Say("牛大勇","听了道友一席话，令我茅塞顿开。")
	runner.Say("牛大勇","这些东西就作为酬劳了，小小心意，不成敬意。")
	runner.AddItem(73005,1,1)
	runner.AddItem(73006,1,1)
end

function 体道大会.小节5(runner, env)
	runner.SetChar("李大锤", 7701)
	runner.PSay("你兴致已尽，正欲离开会场。")
	runner.Say("李大锤","道友此次，收获如何？")
	runner.Say("主角","哈哈，受益良多啊。")
	runner.Say("李大锤","那我们有缘再见，哈哈。")
	runner.SetInt("体道大会开始", 0)
	runner.SetInt("完成体道大会", 10)
end

function 体道大会.切磋胜利(runner, env)
	runner.SetChar("苏大强", 7705)
	runner.Say("苏大强","道友真是厉害，佩服！")
	runner.Say("苏大强","这两本神通便赠与道友了。")
	runner.AddItem(73003,1,1)
	runner.AddItem(73004,1,1)
	runner.SetInt("体道大会切磋", 1)
end

function 体道大会.切磋失败(runner, env)
	runner.SetChar("苏大强", 7705)
	runner.Say("苏大强","道友还需勤学苦练啊！")
end

return 体道大会