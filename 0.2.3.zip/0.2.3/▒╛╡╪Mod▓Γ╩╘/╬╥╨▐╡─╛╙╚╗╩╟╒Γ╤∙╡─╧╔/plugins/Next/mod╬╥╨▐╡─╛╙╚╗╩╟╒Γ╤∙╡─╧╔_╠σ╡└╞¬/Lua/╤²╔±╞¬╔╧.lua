local 妖神篇上 = {}


function 妖神篇上.幽云迷踪1(runner, env)
	
	
end

function 妖神篇上.小柒论道2(runner, env)
	runner.ShowCG("小柒论道")
	runner.PlayEffect("论道")
	
end

function 妖神篇上.小柒手艺2(runner, env)
	runner.ShowCG("小柒手艺")
	runner.PlayEffect("搞怪")
	runner.Say("小柒","好消息就是，为了庆祝你来了，我决定亲自下厨~~")
	runner.Say("洛小乙","...")
	runner.Say("莫小冉","...")
	runner.Say("主角","怎么了，怎么一脸阴沉？")
	runner.Say("洛小乙","偷偷告诉你吧，小柒的味觉，可能有点..问题？")
	runner.Say("洛小乙","她做的饭，非常非常非常非常难吃。")
	runner.Say("莫小冉","就算我是貔貅，啥都能吃，她做的饭我也一口也咽不下去。")
	runner.Say("洛小乙","关键是，她自己完全没感觉，而且吃得很香。")
	runner.Say("莫小冉","按理说猫的味觉应该相当好才对，难道因为她是灵猫？")
	runner.PSay("你看着一唱一和的两人，心情不免也沉重了起来。")
	runner.Say("主角","我也好久没来了，我一起来帮忙吧！别客气！")
	runner.PSay("你凑上前去，想要夺过小柒的铲子。")
	runner.Say("小柒","别客气，我一个人就行了，你就~放心的~在那边等着吧。")
	runner.PSay("小柒一把把你推开，看来帮忙是不可能了。")
	runner.Say("主角","唉，希望不要太过难吃。")
	runner.PSay("你坐在一旁，观察起小柒的动作。")
	runner.PSay("只见小柒将食材倒入锅中，熟练的翻炒起来。")
	runner.Say("主角","看着动作，挺娴熟的啊。")
	runner.PSay("这个时候，突然，小柒抓起盐罐子，哗哗哗往里倒。")
	runner.Say("主角","啊？")
	runner.PSay("但是小柒没有停手，又拿起酱油瓶，哗哗哗的往里接着倒，然后是醋。")
	runner.PSay("你目瞪口呆的看着她把调料全加完，锅里已经是黑乎乎一片，连食材是什么都分不清了。")
	runner.Say("主角","啊？")
	runner.PSay("这时，最令你震惊的一幕发生了，只见小柒搅起一勺尝了一口。")
	runner.Say("小柒","不错，味道刚刚好！")
	runner.Say("主角","啊？")
	runner.PSay("你将震惊的目光投向洛小乙，洛小乙一阵习以为常的表情。")
	runner.Say("小柒","出锅了，来尝尝我的美食。")
	runner.Say("小柒","一人一碗，不许浪费哦~~")
	runner.PSay("你尝试性的尝了一口，顿时，各种味道在你的舌尖舞蹈，你感觉一瞬间已经体验了人生百态。")
	runner.Say("主角","我今天不是很饿，就不吃了吧。")
	runner.Say("小柒","我辛辛苦苦做的，你怎么能就尝一口，今天必须吃完，不许浪费！")
	runner.PSay("小柒满脸凌厉之色。你心中暗叫一声不好，只能用灵气隔绝食物的味道，强行下咽。")
	runner.PSay("-------------------")
	runner.PSay("终于，在灵力的帮助下，你成功'解决'了小柒的'盛宴'。")
	runner.Say("小柒","味道是不是很好？我精心烹饪的。")
	runner.Say("主角","味道太好了（咬牙切齿），下次一定由我来下厨，给你露一手。")
	runner.Say("小柒","哈哈，好的！")
end

return 妖神篇上