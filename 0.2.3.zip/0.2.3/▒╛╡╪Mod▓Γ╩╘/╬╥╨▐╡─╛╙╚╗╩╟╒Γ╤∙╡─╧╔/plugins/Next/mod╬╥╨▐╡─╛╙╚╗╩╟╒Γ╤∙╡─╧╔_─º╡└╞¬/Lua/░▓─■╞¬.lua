local 安宁篇 = {}

function 安宁篇.偷听对话1(runner, env)
	
end

return 安宁篇